#Q1

SELECT s.SupplierID,sd.SupplierName,t.quarters,t.months,SUM(s.Revenue) AS TotalSales
FROM Sales s
JOIN `Supplier-Dimension` sd ON s.SupplierID = sd.SupplierID
JOIN `Time` t ON s.TimeID = t.TimeID
GROUP BY s.SupplierID, sd.SupplierName, t.quarters, t.months
ORDER BY s.SupplierID, t.quarters, t.months;

#Q2

SELECT p.ProductName, t.years, t.months, sd.SupplierName, SUM(s.Revenue) AS TotalSales
FROM Sales s
JOIN `Product-Dimension` p ON s.ProductID = p.ProductID
JOIN `Supplier-Dimension` sd ON s.SupplierID = sd.SupplierID
JOIN `Time` t ON s.TimeID = t.TimeID
WHERE sd.SupplierName = 'DJI' AND t.years = 2019
GROUP BY p.ProductName, t.years, t.months, sd.SupplierName WITH ROLLUP
ORDER BY p.ProductName, t.years, t.months, sd.SupplierName;

#Q3

SELECT p.ProductID,p.ProductName,SUM(s.Quantity) AS TotalQuantitySold
FROM Sales s
JOIN `Product-Dimension` p ON s.ProductID = p.ProductID
JOIN `Time` t ON s.TimeID = t.TimeID
WHERE t.weeks IN (1, 7) 
GROUP BY p.ProductID, p.ProductName
ORDER BY TotalQuantitySold DESC
LIMIT 5;

#Q4

SELECT p.ProductID, p.ProductName, SUM(CASE WHEN t.quarters = 1 THEN s.Revenue ELSE 0 END) AS Q1_Sales, SUM(CASE WHEN t.quarters = 2 THEN s.Revenue ELSE 0 END) AS Q2_Sales,
SUM(CASE WHEN t.quarters = 3 THEN s.Revenue ELSE 0 END) AS Q3_Sales, SUM(CASE WHEN t.quarters = 4 THEN s.Revenue ELSE 0 END) AS Q4_Sales, SUM(s.Revenue) AS TotalYearlySales
FROM Sales s
JOIN `Product-Dimension` p ON s.ProductID = p.ProductID
JOIN `Time` t ON s.TimeID = t.TimeID
WHERE t.years = 2019
GROUP BY p.ProductID, p.ProductName
ORDER BY p.ProductID;

#Q6

CREATE VIEW STOREANALYSIS_MV AS
SELECT s.StoreID AS STORE_ID, p.ProductID AS PROD_ID, SUM(s.Revenue) AS STORE_TOTAL
FROM Sales s
JOIN `Product-Dimension` p ON s.ProductID = p.ProductID
JOIN `Store-Dimension` sd ON s.StoreID = sd.StoreID
GROUP BY s.StoreID, p.ProductID;
SELECT *FROM STOREANALYSIS_MV;

#Q7

SELECT p.ProductID, p.ProductName, t.months, SUM(s.Revenue) AS TotalSales
FROM Sales s
JOIN `Product-Dimension` p ON s.ProductID = p.ProductID
JOIN `Store-Dimension` sd ON s.StoreID = sd.StoreID
JOIN `Time` t ON s.TimeID = t.TimeID
WHERE sd.StoreName = 'Tech Haven'
GROUP BY p.ProductID, p.ProductName, t.months
ORDER BY p.ProductID, t.months;

#Q8

CREATE VIEW SUPPLIER_PERFORMANCE_MV AS
SELECT s.SupplierID, t.months, SUM(s.Revenue) AS MONTHLY_REVENUE
FROM Sales s
JOIN `Time` t ON s.TimeID = t.TimeID
GROUP BY s.SupplierID, t.months;

SELECT* FROM SUPPLIER_PERFORMANCE_MV;

#Q9

SELECT c.CustomerID, c.CustomerName, COUNT(DISTINCT s.ProductID) AS UniqueProductsPurchased, SUM(s.Revenue) AS TotalSales
FROM Sales s
JOIN `Customer-Dimension` c ON s.CustomerID = c.CustomerID
JOIN `Time` t ON s.TimeID = t.TimeID
WHERE t.years = 2019
GROUP BY c.CustomerID, c.CustomerName
ORDER BY TotalSales DESC
LIMIT 5;

#Q10

CREATE VIEW CUSTOMER_STORE_SALES_MV AS
SELECT s.StoreID, c.CustomerID, t.months, SUM(s.Revenue) AS MONTHLY_REVENUE
FROM Sales s
JOIN `Customer-Dimension` c ON s.CustomerID = c.CustomerID
JOIN `Store-Dimension` sd ON s.StoreID = sd.StoreID
JOIN `Time` t ON s.TimeID = t.TimeID
GROUP BY s.StoreID, c.CustomerID, t.months;

SELECT* FROM CUSTOMER_STORE_SALES_MV;