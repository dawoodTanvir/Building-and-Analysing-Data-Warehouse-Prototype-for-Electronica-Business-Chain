#Electronica-DW Project with Hybrid Join Algorithm

1. Download and extract the Zipped Folder.

2.In the zipped folder there will be a zipped file named "ETL". You have to import that folder in Java Eclipse.

3.In the folder i have also provided jar files which you have to add in you Java Project and they are important so must add them.

4.After adding those jar files now you just have yo run the code.

5.The Star Schema is implemented in MYSQL. So, make sure you first run the createDW file to create data warehouse. After this you can run the Java Project.

6.I have provided queries file so you can check the data that went in to the data warehouse.

Thats All!
