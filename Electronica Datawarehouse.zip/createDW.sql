CREATE DATABASE `Electronica-DW`;

USE `Electronica-DW`;

CREATE TABLE `Product-Dimension` (
    ProductID INT PRIMARY KEY NOT NULL,
    ProductName VARCHAR(200),
    ProductPrice DOUBLE
);

CREATE TABLE `Customer-Dimension` (
    CustomerID INT PRIMARY KEY NOT NULL,
    CustomerName VARCHAR(200) NOT NULL,
    Gender VARCHAR(200)
);

CREATE TABLE `Store-Dimension` (
    StoreID INT PRIMARY KEY NOT NULL,
    StoreName VARCHAR(200)
);

CREATE TABLE `Supplier-Dimension` (
    SupplierID INT PRIMARY KEY NOT NULL,
    SupplierName VARCHAR(200)
);

CREATE TABLE `Order-Dimension` (
    OrderID INT PRIMARY KEY NOT NULL,
    OrderDate varchar(200)
);

CREATE TABLE `Time` (
    
    TimeID int Primary key,
    days INT,
    weeks INT,
    months INT,
    quarters INT,
    years INT
    
);

CREATE TABLE `Sales` (
    SaleID INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    ProductID INT,
    CustomerID INT,
    StoreID INT,
    SupplierID INT,
    OrderID INT,
    TimeID int,
    Quantity INT,
    Revenue FLOAT,
    FOREIGN KEY (ProductID) REFERENCES `Product-Dimension`(ProductID),
    FOREIGN KEY (CustomerID) REFERENCES `Customer-Dimension`(CustomerID),
    FOREIGN KEY (StoreID) REFERENCES `Store-Dimension`(StoreID),
    FOREIGN KEY (SupplierID) REFERENCES `Supplier-Dimension`(SupplierID),
    FOREIGN KEY (OrderID) REFERENCES `Order-Dimension`(OrderID),
    FOREIGN KEY (TimeID) REFERENCES `Time`(TimeID)
);











